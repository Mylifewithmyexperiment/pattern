### Project Requirements

* Latest version of JDK.

* Latest version of maven.



### Build Instructions

Run the following command -

 $ mvn clean package

#### Running the project

From the project directory, run this command -

   $ java -jar target\parking-0.1.jar  (Interactive command-line mode)
   
   $ java -jar target\parking-0.1.jar input.txt <inputfile> (File input)