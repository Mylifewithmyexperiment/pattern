# Parking-Lot-Project-Java-
class: Computer Science II (Java)
Programming language: Java

Bus class represents a bus object, and it is a child class of Vehicle class.

Car class represents a car object, and it is a child class of Vehicle class.

Motorcycle class represents a motorcycle object, and it is a child class of Vehicle class.

Level class creates rows on each level of parking lot and check if there are spots available.

ParkingLot class determines the number of level and number of spot on each level of the parking lot.


ParkingSpot class constructs the three types of parking spot.

Vehicle class is a parent class, and it has general features of a vehicle such as how many spots and what kind of size needed for certain type of vehicle.

VehicleSize class

Testing2 class is the userInterface file.

How to run the program:
Please run the Testing2 file.
